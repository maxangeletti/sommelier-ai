# SommelierAI — Rapporto di Collaudo GT v2.0

**Data:** 2026-03-20  
**Dataset:** 100 vini (wines_normalized.csv — 101 righe incl. header)  
**Endpoint:** `POST https://sommelier-ai.onrender.com/search`  
**Build:** post scala tannicità AIS 5 livelli + tannin_req separato  
**Matrice riferimento:** RANKING_TEST_MATRIX_v2_0.md (26 test)

---

## 1. Preflight

| Check | Risultato |
|-------|-----------|
| Dataset size | 100 vini ✅ (verificato localmente, confermare su Render) |
| Frappato Sicilia DOC presente | id=64 ✅ |
| Cerasuolo di Vittoria DOCG presente | id=92 ✅ |
| Etna Rosso/Bianco/Rosato presenti | id=15, 26, 32, 37, 93 ✅ |
| Render endpoint raggiungibile | ⏳ Da verificare con `gt_runner.sh` |

---

## 2. Esecuzione GT Pre-Fix

> **Istruzioni:** Eseguire `bash gt_runner.sh` PRIMA di applicare i fix.
> Compilare la colonna Verdict con PASS / WARN / FAIL.
> Copiare i top 3 risultati per ogni GT dal file di output.

### GT Originali (GT-01 → GT-13)

| GT | Query | Verdict | Top 3 | Note |
|----|-------|---------|-------|------|
| GT-01 | `barolo serralunga` | ___ | | |
| GT-02 | `formaggi erborinati` | ___ | | |
| GT-03 | `franciacorta brut` | ___ | | |
| GT-04 | `vino per cena importante` | ___ | | |
| GT-05 | `rosso strutturato` | ___ | | |
| GT-06 | `bianco fresco` | ___ | | |
| GT-07 | `rosso elegante` | ___ | | |
| GT-08 | `rosso elegante per cena importante` | ___ | | |
| GT-09 | `bianco fresco per cena importante di pesce` | ___ | | |
| GT-10 | `vino importante` | ___ | | |
| GT-11 | `vino importante di pesce` | ___ | | |
| GT-12 | `bottiglia importante` | ___ | | |
| GT-13 | `vino che faccia figura` | ___ | | |

### GT Tannicità (GT-14 → GT-17)

| GT | Query | Verdict | Top 3 | Note |
|----|-------|---------|-------|------|
| GT-14 | `vino tannico e strutturato` | ___ | | |
| GT-15 | `rosso leggero poco tannico` | ___ | | |
| GT-16 | `rosso elegante non troppo tannico` | ___ | | |
| GT-17 | `vino potente per cena importante` | ___ | | |

### GT Copertura (GT-18 → GT-26)

| GT | Query | Verdict | Top 3 | Note |
|----|-------|---------|-------|------|
| GT-18 | `poco tannico` | ___ | | |
| GT-19 | `vino tannico` | ___ | | |
| GT-20 | `vino sotto 20 euro` | ___ | | |
| GT-21 | `nebbiolo` | ___ | | |
| GT-22 | `rosato per aperitivo` | ___ | | |
| GT-23 | `prosecco` | ___ | | |
| GT-24 | `etna` | ___ | | Atteso FAIL pre-fix (parse_region non matcha) |
| GT-25 | `vino dolce` | ___ | | |
| GT-26 | `voglio stupire` | ___ | | Atteso FAIL pre-fix (prestige non cattura) |

---

## 3. Analisi Bug e Fix Applicati

### Bug GT-24: "etna" — parse_region + filtro AND

**Root cause (doppio):**

1. `REGION_PATTERNS` conteneva solo 11 regioni macro (Piemonte, Toscana, etc.) ma nessuna **zona** (Etna, Langhe, Chianti, etc.). La query "etna" non produceva alcun `region` parsato → nessun filtro geografico → risultati generici basati solo su qualità intrinseca.

2. Il filtro regione (riga 2094) aveva un **bug logico AND sequenziale**: il `for` loop applicava `_filter_by_text_contains` su ogni colonna in sequenza (`region` → `zone` → `denomination` → `country`), il che richiedeva che il valore fosse presente in **tutte** le colonne contemporaneamente. Esempio: "etna" in `region` (Sicilia ≠ Etna) → 0 risultati → DataFrame vuoto per sempre. Con la vecchia lista patterns questo bug era latente perché matchava solo regioni presenti nel campo `region`.

**Fix applicati:**

| # | Cosa | Classificazione |
|---|------|----------------|
| FIX 1 | `REGION_PATTERNS`: +20 zone/regioni (etna, langhe, franciacorta, chianti, montalcino, bolgheri, barolo, barbaresco, soave, chablis, pauillac, sancerre, priorat, campania, calabria, sardegna, umbria, friuli, abruzzo, lazio, liguria, marche, provence) | B |
| FIX 2 | Filtro regione: AND sequenziale → **OR** con `pd.Series` mask | B |

**Effetto collaterale positivo:** GT-01 "barolo serralunga" ora beneficia del pattern "barolo" come zona → il filtro OR restringe ai 3 vini Barolo DOCG (denominazione=Barolo), migliorando la precisione.

### Bug GT-26: "voglio stupire" — parse_prestige_intent

**Root cause:** `parse_prestige_intent` aveva 6 pattern tutti focalizzati su linguaggio formale ("vino importante", "bottiglia importante", "fare figura", "di livello", "prestigioso", "premium"). Il linguaggio informale/emotivo ("voglio stupire", "far colpo") non era coperto.

**Fix applicato:**

| # | Cosa | Classificazione |
|---|------|----------------|
| FIX 3 | `parse_prestige_intent`: +5 pattern (`stupire`, `far colpo`, `impressionare`, `vino wow`, `effetto wow`) | B |

**Verifica locale:**
```
parse_prestige_intent("voglio stupire") → True ✅
parse_prestige_intent("vino importante") → True ✅ (regressione: nessuna)
parse_prestige_intent("bianco fresco") → False ✅ (falso positivo: nessuno)
```

---

## 4. Esecuzione GT Post-Fix

> **Istruzioni:** Dopo deploy di `main_patched.py`, eseguire `bash gt_runner.sh`.
> Compilare SOLO GT-24 e GT-26 (gli altri non dovrebbero cambiare).
> Se altri GT cambiano, documentare come regressione o miglioramento.

### GT-24 Post-Fix

| GT | Query | Verdict | Top 3 | Note |
|----|-------|---------|-------|------|
| GT-24 | `etna` | ___ | | Atteso: Etna Rosso, Etna Bianco, Etna Rosato in top 3 |

### GT-26 Post-Fix

| GT | Query | Verdict | Top 3 | Note |
|----|-------|---------|-------|------|
| GT-26 | `voglio stupire` | ___ | | Atteso: Barolo, Pauillac, Gevrey in top 3 |

### Regressioni (GT che cambiano verdict post-fix)

| GT | Pre-Fix | Post-Fix | Causa |
|----|---------|----------|-------|
| GT-01 | ___ | ___ | barolo ora matchato come zona → filtro più preciso |
| | | | |

---

## 5. Sommario Finale

| Metrica | Pre-Fix | Post-Fix |
|---------|---------|----------|
| PASS | ___/26 | ___/26 |
| WARN | ___/26 | ___/26 |
| FAIL | ___/26 | ___/26 |
| Dataset | 100 vini | 100 vini |
| Fix applicati | — | 3 (classificazione B) |

---

## 6. Gap Residui e Backlog

### Vitigni mancanti in KNOWN_GRAPES
I seguenti vitigni del dataset 100 vini non sono in `KNOWN_GRAPES` (riga 313):
- `nerello mascalese`, `nerello cappuccio` (Etna)
- `frappato` (Sicilia)
- `carricante` (Etna Bianco)
- `sagrantino` (Montefalco)
- `cesanese` (Piglio)
- `verdicchio` (Marche)
- `pecorino` (Abruzzo/Marche)
- `nero d'avola` ✅ (già presente)
- `garganega` (Soave)
- `corvina` ✅ (già presente)
- `lagrein` (Alto Adige)
- `gewurztraminer` (Alsazia/Alto Adige)
- `albarino` (Rias Baixas)
- `touriga nacional` (Douro)

**Priorità:** Bassa — il vitigno matching funziona solo per vitigni in KNOWN_GRAPES, ma non impatta i GT attuali. Da fare in una sessione dedicata di arricchimento parser.

### LLM Integration
Il file `llm_intent_parser.py` resta **non integrato** nel motore. I fix GT-24/GT-26 sono rule-based. Per query veramente laterali ("qualcosa di estivo ma non banale", "amici che amano la Francia"), serve l'integrazione LLM (backlog alta priorità).

### Denominazioni come filter
Query come "barolo serralunga" ora matchano "barolo" come zona, il che funziona. Ma "franciacorta" è sia zona che denominazione — il pattern approach funziona ma non è robusto per il long term. Considerare un parsing più strutturato (zone_dict con mapping espliciti) in una sessione dedicata.

---

## 7. Procedura di Deploy

```bash
# 1. Backup
cp backend/main.py backend/main_backup_20260320.py

# 2. Applica patch
cp main_patched.py backend/main.py

# 3. Commit
git add backend/main.py
git commit -m "fix(parser): GT-24 etna zone match + GT-26 prestige 'voglio stupire' [B]"

# 4. Deploy
git push origin main
# Render auto-deploy on push

# 5. Wait for deploy (~2 min) then run GT
sleep 120
bash gt_runner.sh

# 6. Verifica GT-24 e GT-26 sono PASS
```

---

*Rapporto generato il 2026-03-20 — Compilare le sezioni ___ dopo esecuzione dei test.*
